# -*- encoding:ascii -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 8
_modified_time = 1340523477.899264
_enable_loop = True
_template_filename = 'templates/quagga/etc/zebra/bgp.conf.mako'
_template_uri = 'templates/quagga/etc/zebra/bgp.conf.mako'
_source_encoding = 'ascii'
_exports = []


def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        node = context.get('node', UNDEFINED)
        __M_writer = context.writer()
        # SOURCE LINE 1
        __M_writer(unicode(node))
        return ''
    finally:
        context.caller_stack._pop_frame()


