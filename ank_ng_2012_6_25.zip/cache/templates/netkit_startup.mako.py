# -*- encoding:ascii -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 8
_modified_time = 1340523477.869873
_enable_loop = True
_template_filename = 'templates/netkit_startup.mako'
_template_uri = 'templates/netkit_startup.mako'
_source_encoding = 'ascii'
_exports = []


def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        node = context.get('node', UNDEFINED)
        __M_writer = context.writer()
        # SOURCE LINE 1
        for interface in node.interfaces:  
            # SOURCE LINE 2
            __M_writer(u'/sbin/ifconfig ')
            __M_writer(unicode(interface.id))
            __M_writer(u' ')
            __M_writer(unicode(interface.ip_address))
            __M_writer(u' netmask ')
            __M_writer(unicode(interface.subnet.netmask))
            __M_writer(u' broadcast ')
            __M_writer(unicode(interface.subnet.broadcast))
            __M_writer(u' up\n')
            pass
        # SOURCE LINE 4
        __M_writer(u'route del default\n/etc/init.d/zebra start\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


